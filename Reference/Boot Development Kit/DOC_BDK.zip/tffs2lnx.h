/*
 * $Log: tffs2lnx.h,v $
 * Revision 1.1  2004/07/19 07:42:01  alvislin
 * add Msys DOCPLUS support for Synology IXP420 DS hardware
 * add Msys char device & Msys SDK
 *
 * 
 */

/***********************************************************************************/
/*                        M-Systems Confidential                                   */
/*           Copyright (C) M-Systems Flash Disk Pioneers Ltd. 1995-2002            */
/*                         All Rights Reserved                                     */
/***********************************************************************************/
/*                            NOTICE OF M-SYSTEMS OEM                              */
/*                           SOFTWARE LICENSE AGREEMENT                            */
/*                                                                                 */
/*      THE USE OF THIS SOFTWARE IS GOVERNED BY A SEPARATE LICENSE                 */
/*      AGREEMENT BETWEEN THE OEM AND M-SYSTEMS. REFER TO THAT AGREEMENT           */
/*      FOR THE SPECIFIC TERMS AND CONDITIONS OF USE,                              */
/*      OR CONTACT M-SYSTEMS FOR LICENSE ASSISTANCE:                               */
/*      E-MAIL = info@m-sys.com                                                    */
/***********************************************************************************/

#ifndef ___TFFS2LNX__H__
#define ___TFFS2LNX__H__

/* Set DiskOnChip Window Address */
#define FL_DOC_WIN_SIZE		0x2000l
#define FL_DOC_PHYS_ADDR_LOW	0x50000000l
#define FL_DOC_PHYS_ADDR_HIGH	0x50004000l

void fl_docCsInit( void );
int fl_mapPhysMem( unsigned long winl, unsigned long winh );
void fl_releasePhysMem( unsigned long winl, unsigned long winh );

/* Driver Functions */
unsigned char FlInit(void);
unsigned char FlMount(unsigned char bDevice);
unsigned char FlIsExist(unsigned char bDevice);
unsigned char FlIsReadProt(unsigned char bDevice);
unsigned char FlIsWriteProt(unsigned char bDevice);
unsigned char FlGetProtection(unsigned char bDevice);
unsigned char FlRemoveProtectionFromParm(unsigned char bHandle,unsigned char*pKey);
unsigned char FlDismount(unsigned char bDevice);
int FlGetNumberOfDevices(int max);
unsigned long FlGetNumberOfSectors(unsigned char bDevice);
unsigned char FlRead(unsigned char bDevice, void *data, int block, int count);
unsigned char FlWrite(unsigned char bDevice, void *data, int block, int count);
int FlIoctl(unsigned irHandle, int cmd,unsigned long arg);

#define MAX_DEVICES		4	/* "imported" from OSAK, MAX_DEVICES>=VOLUMES from flcustom.h */

/* non-OSAK IOCTLs defenitions */
#define FL_IOCTL_LNX	(FL_IOCTL_EXTENDED_WRITE_IPL+1)
typedef struct
{
	unsigned long command;
	unsigned long data;
} flInputLnxRecord;
typedef struct
{
	unsigned long status;
	unsigned long data;
} flOutputLnxRecord;
/* end of non-OSAK IOCTLs defenitions */

#endif	/* ___TFFS2LNX__H__ */
