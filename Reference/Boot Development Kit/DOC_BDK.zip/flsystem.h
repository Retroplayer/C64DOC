/*
 * $Log: flsystem.h,v $
 * Revision 1.1  2004/07/19 07:42:00  alvislin
 * add Msys DOCPLUS support for Synology IXP420 DS hardware
 * add Msys char device & Msys SDK
 *
 * 
 */

/************************************************************************/
/*                                                                      */
/*              FAT-FTL Lite Software Development Kit                   */
/*              Copyright (C) M-Systems Ltd. 1995-2002                  */
/*                                                                      */
/************************************************************************/

/* flsystem.h for linux kernel mode*/

#ifndef FLSYSTEM_H
#define FLSYSTEM_H

#include "flcustom.h"

/* DiskOnChip bus configuration
 *
 * When FL_NO_USE_FUNC is defined use the defintion bellow to set DiskOnChip
 * bus width access (either 8/16/32).  
 * Please check the manula before deciding to use the FL_NO_USE_FUNC mode.
 */

#define DOC_ACCESS_TYPE 16

/* 			NULL constant
 *
 * Some compilers require a different definition for the NULL pointer
 */

#ifndef NULL
	#define NULL ((void *) 0)
#endif

/* 			Far pointers
 *
 * Specify here which pointers may be far, if any.
 * Far pointers are usually relevant only to 80x86 architectures.
 *
 * Specify FAR_LEVEL:
 *   0 -	if using a flat memory model or having no far pointers.
 *   1 -        if only the socket window may be far
 *   2 -	if only the socket window and caller's read/write buffers
 *		may be far.
 *   3 -	if socket window, caller's read/write buffers and the
 *		caller's I/O request packet may be far
 */

#define FAR_LEVEL	0

/*
 * Yielding the CPU
 *
 * TrueFFS utilizes the routine flSleep to yield the CPU while
 * waiting for time consuming operations like a flash erase. 
 * If the routine is not implemented, then uncomment the define below.
 */

#define DO_NOT_YIELD_CPU

/* Little-endian/big-endian
 *
 * FAT and translation layer structures use the little-endian (Intel)
 * format for integers.
 * If your machine uses the big-endian (Motorola) format, uncomment the
 * following line.
 * Note that even on big-endian machines you may omit the BIG_ENDIAN
 * definition for smaller code size and better performance, but your media
 * will not be compatible with standard FAT and FTL.
 */

#define FL_BIG_ENDIAN

/* Pointer arithmetic
 *
 * The following macros define machine- and compiler-dependent macros for
 * handling pointers to physical window addresses. The definitions below are
 * for PC real-mode Borland-C.
 *
 * 'physicalToPointer' translates a physical flat address to a (far) pointer.
 * Note that if your processor uses virtual memory, the code should
 * map the physical address to virtual memory, and return a pointer to that
 * memory (the size parameter tells how much memory should be mapped).
 *
 * 'addToFarPointer' increments to a pointer and returns a new
 * pointer. The increment may be as large as your window size. The code
 * below assumes that the increment may be larger than 64 KB and so performs
 * huge pointer arithmetic.
 */

#define physicalToPointer(physical,size,drive) ((void *) (physical))

#define pointerToPhysical(ptr)  ((unsigned long)(ptr))

#define addToFarPointer(base,increment) ((void *) ((unsigned char *) (base) + (increment)))

#define freePointer(ptr,size) 1

/* Naming convention for functions that uses non-default convention. */
/* use GNU C default calling convention */

#define NAMING_CONVENTION

/* Mutex type
 *
 * If you intend to access the TrueFFS API in a multi-tasking environment,
 * you may need to implement some resource management and mutual-exclusion
 * of TrueFFS with mutex & semaphore services that are available to you. In
 * this case, define here the Mutex type you will use, and provide your own
 * implementation of the Mutex functions in flcustom.c
 *
 * By default, a Mutex is defined as a simple counter, and the Mutex
 * functions in flcustom.c implement locking and unlocking by incrementing
 * and decrementing the counter. This will work well on all single-tasking
 * environments, as well as on many multi-tasking environments.
 */

typedef int FLMutex;

#define flStartCriticalSection(FLMutex)		disable()
#define flEndCriticalSection(FLMutex)		enable()

/* Memory allocation
 *
 * The translation layers (e.g. FTL, NFTL, INFTL) need to allocate memory to 
 * handle the Flash media. The required size depends on the media being handled.
 *
 * You may choose to use the standard 'malloc' and 'free' to handle such
 * memory allocations, provide your own equivalent routines, or you may
 * choose not to define any memory allocation routine. In this case, the
 * memory will be allocated statically at compile-time on the assumption of
 * the largest media configuration you need to support. This is the simplest
 * choice, but may cause your RAM requirements to be larger than you
 * actually need.
 *
 * If you define routines other than malloc & free, they should have the
 * same parameters and return types as malloc & free. You should either code
 * these routines in flcustom.c or include them when you link your application.
 */

#define MALLOC	flmalloc
#define FREE	flfree

/* Debug mode
 *
 * Uncomment the following lines if you want debug messages to be printed
 * out. Messages will be printed at initialization key points, and when
 * low-level errors occure.
 * You may choose to use 'printf' or provide your own routine.
 */

#define DEBUG_PRINT(str)	FlDebugPrint(str)

/* Special debug massages for dformat utility */
#define DFORMAT_PRINT(str)
/* File open macro */
#define FL_FOPEN
/* File close macro */
#define FL_FCLOSE
/* File printf macro */
#define FL_FPRINTF

#define flcpy flmemcpy
#define flcmp flmemcmp
#define flset flmemset


#include <linux/sockios.h> /* for SIOCDEVPRIVATE */
#define FL_IOCTL_START SIOCDEVPRIVATE

#endif
