
/*
 * $Log: osak.h,v $
 * Revision 1.1  2004/07/19 07:42:01  alvislin
 * add Msys DOCPLUS support for Synology IXP420 DS hardware
 * add Msys char device & Msys SDK
 *
 * 
 *    Rev 1.1   Apr 01 2001 07:46:32   oris
 * Updated copywrite notice
 * 
 *    Rev 1.0   Feb 04 2001 12:35:48   oris
 * Initial revision.
 *
 */

/************************************************************************/
/*                                                                      */
/*		DiskOnChip 2000 O/S Adaptation Kit			*/
/*		Copyright (C) M-Systems Ltd. 1998			*/
/*									*/
/************************************************************************/


#ifndef OSAK_H
#define OSAK_H

#include "blockdev.h"
#include "dosformt.h"

#endif
