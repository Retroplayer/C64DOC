/*
 * $Log: fldrvlnx.h,v $
 * Revision 1.1  2004/07/19 07:42:00  alvislin
 * add Msys DOCPLUS support for Synology IXP420 DS hardware
 * add Msys char device & Msys SDK
 *
 */

/***********************************************************************************/
/*                        M-Systems Confidential                                   */
/*           Copyright (C) M-Systems Flash Disk Pioneers Ltd. 1995-2001            */
/*                         All Rights Reserved                                     */
/***********************************************************************************/
/*                            NOTICE OF M-SYSTEMS OEM                              */
/*                           SOFTWARE LICENSE AGREEMENT                            */
/*                                                                                 */
/*      THE USE OF THIS SOFTWARE IS GOVERNED BY A SEPARATE LICENSE                 */
/*      AGREEMENT BETWEEN THE OEM AND M-SYSTEMS. REFER TO THAT AGREEMENT           */
/*      FOR THE SPECIFIC TERMS AND CONDITIONS OF USE,                              */
/*      OR CONTACT M-SYSTEMS FOR LICENSE ASSISTANCE:                               */
/*      E-MAIL = info@m-sys.com                                                    */
/***********************************************************************************/

#ifndef __FLDRVLNX__H__
#define __FLDRVLNX__H__

#include <linux/sockios.h> /* for SIOCDEVPRIVATE */

typedef enum{FL_IOCTL_GET_INFO = SIOCDEVPRIVATE,
             FL_IOCTL_DEFRAGMENT,
             FL_IOCTL_WRITE_PROTECT,
             FL_IOCTL_MOUNT_VOLUME,
             FL_IOCTL_FORMAT_VOLUME,
             FL_IOCTL_BDK_OPERATION,
             FL_IOCTL_DELETE_SECTORS,
             FL_IOCTL_READ_SECTORS,
             FL_IOCTL_WRITE_SECTORS,
             FL_IOCTL_FORMAT_PHYSICAL_DRIVE,
             FL_IOCTL_FORMAT_LOGICAL_DRIVE,
             FL_IOCTL_BDTL_HW_PROTECTION,
             FL_IOCTL_BINARY_HW_PROTECTION,
             FL_IOCTL_OTP,
             FL_IOCTL_CUSTOMER_ID,
             FL_IOCTL_UNIQUE_ID,
             FL_IOCTL_NUMBER_OF_PARTITIONS,
             FL_IOCTL_INQUIRE_CAPABILITIES,
             FL_IOCTL_SET_ENVIRONMENT_VARIABLES, /* No longer supported */
             FL_IOCTL_PLACE_EXB_BY_BUFFER,
             FL_IOCTL_WRITE_IPL,                 /* No longer supported */
             FL_IOCTL_DEEP_POWER_DOWN_MODE,
             FL_IOCTL_EXTENDED_ENVIRONMENT_VARIABLES, 
             FL_IOCTL_VERIFY_VOLUME,
             FL_IOCTL_SET_ACCESS_ROUTINE,
             FL_IOCTL_GET_ACCESS_ROUTINE,
             FL_IOCTL_EXTENDED_WRITE_IPL
} flIOctlFunctionNo;

#ifndef FLASH_MAJOR
#define FLASH_MAJOR	100
#endif

#endif	/*#ifndef __FLDRVLNX__H__*/
