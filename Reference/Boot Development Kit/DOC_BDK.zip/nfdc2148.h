/*
 * $Log: nfdc2148.h,v $
 * Revision 1.1  2004/07/19 07:42:01  alvislin
 * add Msys DOCPLUS support for Synology IXP420 DS hardware
 * add Msys char device & Msys SDK
 *
 * 
 *    Rev 1.1   Apr 01 2001 07:46:42   oris
 * Updated copywrite notice
 * 
 *    Rev 1.0   Feb 04 2001 12:40:46   oris
 * Initial revision.
 *
 */

/************************************************************************/
/*                                                                      */
/*		FAT-FTL Lite Software Development Kit			*/
/*              Copyright (C) M-Systems Ltd. 1995-2001                  */
/*									*/
/************************************************************************/
#ifndef NFDC2148_H
#define NFDC2148_H

#include "diskonc.h"

#endif /* NFDC2148_H */
