/*
 * $Log: tffs2lnx.c,v $
 * Revision 1.1  2004/07/19 07:42:01  alvislin
 * add Msys DOCPLUS support for Synology IXP420 DS hardware
 * add Msys char device & Msys SDK
 *
 * 
 */

/***********************************************************************************/
/*                        M-Systems Confidential                                   */
/*           Copyright (C) M-Systems Flash Disk Pioneers Ltd. 1995-2001            */
/*                         All Rights Reserved                                     */
/***********************************************************************************/
/*                            NOTICE OF M-SYSTEMS OEM                              */
/*                           SOFTWARE LICENSE AGREEMENT                            */
/*                                                                                 */
/*      THE USE OF THIS SOFTWARE IS GOVERNED BY A SEPARATE LICENSE                 */
/*      AGREEMENT BETWEEN THE OEM AND M-SYSTEMS. REFER TO THAT AGREEMENT           */
/*      FOR THE SPECIFIC TERMS AND CONDITIONS OF USE,                              */
/*      OR CONTACT M-SYSTEMS FOR LICENSE ASSISTANCE:                               */
/*      E-MAIL = info@m-sys.com                                                    */
/***********************************************************************************/

#include "flcustom.h"
#include "flstatus.h"
#include "flreq.h"
#include "flsocket.h"
#include "flsystem.h"
#include "fatfilt.h"
#include "flioctl.h"
#include "blockdev.h"

#include "tffs2lnx.h"

extern unsigned noOfDrives;
static FLStatus stat;
static IOreq ioreq;

typedef struct
{
	unsigned char handle;		/* socket & partition, as ioreq.irHandle */
	unsigned char protection;	/* bit 0 - write prot, bit 1 - read prot */
} DeviceInfo;

static DeviceInfo devices[MAX_DEVICES];

#ifdef FL_POWER_DOWN
void FlPowerDown( unsigned char bDevice )
{
	ioreq.irHandle = devices[bDevice].handle;
	ioreq.irFlags  = DEEP_POWER_DOWN;
	flDeepPowerDownMode( &ioreq );
}
#else
#define FlPowerDown(b)
#endif /* FL_POWER_DOWN */

/* Initialize M-Systems OSAK. */
unsigned char FlInit(void)
{
	unsigned char	bDevice,bSocket;

	stat = flInit();
	if(stat!=flOK)
	{
		FlErrorPrint("FlInit->flInit",stat);
		return FALSE;
	}

	for(bSocket=0,bDevice=0;bDevice<noOfDrives;bSocket++)
	{
		unsigned char bNDevicesOnSocket,bDeviceOnSocket;

		ioreq.irHandle=bSocket;
		stat = flCountVolumes(&ioreq);
		if(stat==flOK)
		{
			bNDevicesOnSocket=ioreq.irFlags;
		}
		else
		{
			FlErrorPrint("FlInit->flCountVolumes",stat);
			return FALSE;
		}

		for(bDeviceOnSocket=0;bDeviceOnSocket<bNDevicesOnSocket;bDeviceOnSocket++,bDevice++)
		{
			devices[bDevice].handle=bSocket|(bDeviceOnSocket<<4);

			devices[bDevice].protection=0;
			ioreq.irHandle=devices[bDevice].handle;
#if 0     /* ALVIS */
			stat=flIdentifyProtection(&ioreq);
			if(stat==flOK)
			{
				if(ioreq.irFlags&(READ_PROTECTED|WRITE_PROTECTED) && (!(ioreq.irFlags&KEY_INSERTED)) )
				{
					if(ioreq.irFlags&READ_PROTECTED)
					{
						devices[bDevice].protection=2;
					}
					if(ioreq.irFlags&WRITE_PROTECTED)
					{
						devices[bDevice].protection|=1;
					}
				}
			}
			else
			{
				if(stat!=flFeatureNotSupported && stat!=flNotProtected)
				{
					FlErrorPrint("FlInit->flIdentifyProtection",stat);
					return FALSE;
				}
			}
#endif
		}
	}

	for(bDevice=noOfDrives;bDevice<MAX_DEVICES;bDevice++)
	{
		devices[bDevice].handle=0xFF;
		devices[bDevice].protection=0;
	}

	return TRUE;
}

unsigned char FlGetProtection(unsigned char bDevice)
{
	return devices[bDevice].protection;
}

unsigned char FlIsExist(unsigned char bDevice)
{
	return devices[bDevice].handle!=0xFF;
}

unsigned char FlIsReadProt(unsigned char bDevice)
{
	return devices[bDevice].protection&2;
}

unsigned char FlIsWriteProt(unsigned char bDevice)
{
	return devices[bDevice].protection&1;
}

/* test mount upto DRIVES volumes to see how many we can find */
int FlGetNumberOfDevices(int max)
{
	return noOfDrives;
}

/* Get the number of sectors in the DOC volume */
unsigned long FlGetNumberOfSectors(unsigned char bDevice)
{
	ioreq.irHandle = devices[bDevice].handle;
	stat = flSectorsInVolume(&ioreq);
	if( stat != flOK )
	{
		FlErrorPrint("FlGetNumberOfSectors->flSectorsInVolume",stat);
		return 0;
	}
	return (unsigned long)ioreq.irLength;
}

/* Perform read or write of appropriate number of sectors from a DOC volume */
unsigned char FlRead(unsigned char bDevice, void *data, int block, int count)
{
	ioreq.irHandle = devices[bDevice].handle;
	ioreq.irData = data;
	ioreq.irSectorNo = block;
	ioreq.irSectorCount = count;
	stat = flAbsRead(&ioreq);
	FlPowerDown( bDevice );
	if( stat != flOK )
	{
		FlErrorPrint("FlRead->flAbsRead",stat);
		return FALSE;
	}
	return TRUE;
}

/* Perform read or write of appropriate number of sectors from a DOC volume */
unsigned char FlWrite(unsigned char bDevice,void*data,int block,int count)
{
	ioreq.irHandle=devices[bDevice].handle;
	ioreq.irData = data;
	ioreq.irSectorNo = block;
	ioreq.irSectorCount = count;
#ifdef FL_FAT_FILTER
	ffCheckBeforeWrite(&ioreq);
#endif /* FL_FAT_FILTER */	
	stat = flAbsWrite(&ioreq);
	FlPowerDown( bDevice );
	if( stat != flOK )
	{
		FlErrorPrint("FlWrite->flAbsWrite",stat);
		return FALSE;
	}
	return TRUE;
}
#if 0 /* ALVIS */
unsigned char FlRemoveProtectionFromParm(unsigned char bDevice,unsigned char*pKey)
{
	IOreq ioreq;
	ioreq.irHandle=devices[bDevice].handle ;
	ioreq.irData=pKey;
	stat = flInsertProtectionKey(&ioreq);
	FlPowerDown( bDevice );
	if( stat != flOK )
	{
		FlErrorPrint("FlRemoveProtectionFromParm->flInsertProtectionKey",stat);
		return FALSE;
	}
	devices[bDevice].protection=0;
	return TRUE;
}
#endif
int FlIoctl(FLHandle irHandle, int cmd,unsigned long arg)
{
	unsigned char bdkVolume=0;

    ioreq.irHandle = irHandle;

	switch(cmd)
	{
	case FL_IOCTL_GET_INFO:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_GET_INFO;
		break;
	case FL_IOCTL_DEFRAGMENT:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_DEFRAGMENT;
		break;
	case FL_IOCTL_WRITE_PROTECT:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_WRITE_PROTECT;
		break;
	case FL_IOCTL_MOUNT_VOLUME:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_MOUNT_VOLUME;
		break;
	case FL_IOCTL_FORMAT_VOLUME:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_FORMAT_VOLUME;
		break;
	case FL_IOCTL_BDK_OPERATION:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_BDK_OPERATION;
		break;
	case FL_IOCTL_DELETE_SECTORS:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_DELETE_SECTORS;
		break;
	case FL_IOCTL_READ_SECTORS:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_READ_SECTORS;
		break;
	case FL_IOCTL_WRITE_SECTORS:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_WRITE_SECTORS;
		break;
	case FL_IOCTL_FORMAT_PHYSICAL_DRIVE:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_FORMAT_PHYSICAL_DRIVE;
		break;
	case FL_IOCTL_FORMAT_LOGICAL_DRIVE:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_FORMAT_LOGICAL_DRIVE;
		break;
	case FL_IOCTL_BDTL_HW_PROTECTION:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_BDTL_HW_PROTECTION;
		break;
	case FL_IOCTL_BINARY_HW_PROTECTION:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_BINARY_HW_PROTECTION;
		break;
	case FL_IOCTL_OTP:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_OTP;
		break;
	case FL_IOCTL_CUSTOMER_ID:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_CUSTOMER_ID;
		break;
	case FL_IOCTL_UNIQUE_ID:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_UNIQUE_ID;
		break;
	case FL_IOCTL_NUMBER_OF_PARTITIONS:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_NUMBER_OF_PARTITIONS;
		break;
	case FL_IOCTL_INQUIRE_CAPABILITIES:
		ioreq.irHandle = 0;
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_INQUIRE_CAPABILITIES;
		break;
	case FL_IOCTL_SET_ENVIRONMENT_VARIABLES:
		ioreq.irHandle = 0;
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_SET_ENVIRONMENT_VARIABLES;
		break;
	case FL_IOCTL_PLACE_EXB_BY_BUFFER:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_PLACE_EXB_BY_BUFFER;
		break;
	case FL_IOCTL_WRITE_IPL:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_WRITE_IPL;
		break;
	case FL_IOCTL_DEEP_POWER_DOWN_MODE:
		ioreq.irData = (void *) arg;
		ioreq.irFlags = FL_IOCTL_DEEP_POWER_DOWN_MODE;
		break;
	case FL_IOCTL_EXTENDED_ENVIRONMENT_VARIABLES:
		ioreq.irData=(void*)arg;
		ioreq.irFlags=FL_IOCTL_EXTENDED_ENVIRONMENT_VARIABLES;
		break;
	case FL_IOCTL_VERIFY_VOLUME:
		ioreq.irData=(void*)arg;
		ioreq.irFlags=FL_IOCTL_VERIFY_VOLUME;
		break;
	case FL_IOCTL_SET_ACCESS_ROUTINE:
		ioreq.irData=(void*)arg;
		ioreq.irFlags=FL_IOCTL_SET_ACCESS_ROUTINE;
		break;
	case FL_IOCTL_GET_ACCESS_ROUTINE:
		ioreq.irData=(void*)arg;
		ioreq.irFlags=FL_IOCTL_GET_ACCESS_ROUTINE;
		break;
	case FL_IOCTL_EXTENDED_WRITE_IPL:
		ioreq.irData=(void*)arg;
		ioreq.irFlags=FL_IOCTL_EXTENDED_WRITE_IPL;
		break;
		
	case FL_IOCTL_LNX:
	default:
		FlErrorPrint("FlIoctl",flBadParameter);
		return FALSE;
	}

	/* do not check error code - it sended by outRec->status */
	flIOctl(&ioreq);
	FlPowerDown(bDevice);
	return TRUE;
}
