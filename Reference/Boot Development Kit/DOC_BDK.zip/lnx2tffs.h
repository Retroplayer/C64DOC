#ifndef __LNX2TFFS__H__
#define __LNX2TFFS__H__

#include <linux/types.h>	/* for size_t */


void GetFlParams(unsigned long*p_fl_winl,unsigned long*p_fl_winh,
	unsigned char*p_fl_is_ram_check,unsigned char*p_fl_nftl_cache,
	unsigned char*p_fl_8bit_access,unsigned long*p_fl_mtd_bus_access_type,
	unsigned long*p_fl_verify_write_bdtl,unsigned long*p_fl_verify_write_binary,
	unsigned long*p_fl_verify_write_other,unsigned long*p_fl_sectors_verified_per_folding);

void FlDebugPrint(char*str);
void FlErrorPrint(char*str,int stat);

#ifdef DEEPDEBUG
void FlLogData(unsigned char*wBuffPtr,unsigned short wLen,unsigned char fWrite);
int FlPrintk(const char *fmt, ...);
#define FLPRINTK(fmt,args...)	FlPrintk(fmt,## args)
#define FLLOGDATA(p,w,f)		FlLogData(p,w,f)
#else	/* DEEPDEBUG */
#define FLPRINTK(fmt,args...)
#define FLLOGDATA(p,w,f)
#endif	/* DEEPDEBUG */

void flDelayMsecs(unsigned);
void flsleep(unsigned long);
unsigned flRandByte(void);

void *flmemcpy(void * dest,const void *src,size_t count);
void *flmemset(void * dest,int cval,size_t count);
int flmemcmp(const void * dest,const void *src,size_t count);

void flmemcpy_fromio(void *, const void *, unsigned int);
void flmemcpy_toio(void *, const void *, unsigned int);
void flmemset_io(void*,int,unsigned int);

void *flmalloc(unsigned long);
void flfree(void *);
void *flAddLongToFarPointer(void*ptr, unsigned long offset);

unsigned char flreadb(volatile void *addr);
unsigned short flreadw(volatile void *addr);
unsigned long flreadl(volatile void *addr);
void flwriteb(unsigned char value, volatile void *addr);
void flwritew(unsigned short value, volatile void *addr);
void flwritel(unsigned long value, volatile void *addr);

/*
#define FLWRITE_IO_BYTE(val,address)		flwriteb((unsigned char)(val),(volatile unsigned char*)(address))
#define FLWRITE_IO_WORD(val,address)		flwritew((unsigned short)(val),(volatile unsigned short*)(address))
#define FLWRITE_IO_DWORD(val,address)		flwritel((unsigned long)(val),(volatile unsigned long*)(address))
#define FLCPY_FROM_IO(dest,src,count)		flmemcpy_fromio(dest,(void*)(src),count)
#define TFFSCPY_FROM_IO(dest,src,count)		flmemcpy_fromio(dest,(void*)(src),count)
#define FLREAD_IO_BYTE(address)				flreadb((volatile unsigned char*)(address))
#define FLREAD_IO_WORD(address)				flreadw((volatile unsigned short*)(address))
#define FLREAD_IO_DWORD(address)			flreadl((volatile unsigned long*)(address))
#define FLCPY_TO_IO(dest,src,count)			flmemcpy_toio((void*)(dest),src,count)
#define FLSET_IO(dest,val,count)			flmemset_io((void*)(dest),val,count)
#define TFFSCPY_TO_IO(dest,src,count)		flmemcpy_toio((void*)(dest),src,count)
#define TFFSSET_IO(dest,val,count)			flmemset_io((void*)(dest),val,count)
*/
#endif	/* __LNX2TFFS__H__ */
