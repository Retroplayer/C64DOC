/*
 * $Log:   
 */

/************************************************************************/
/*                                                                      */
/*              FAT-FTL Lite Software Development Kit                   */
/*              Copyright (C) M-Systems Ltd. 1995-2002                  */
/*                                                                      */
/************************************************************************/

/* flcustom.h for linux driver */

#include "flsystem.h"
#include "stdcomp.h"
#include "blockdev.h"

static unsigned long dwWinL,dwWinH;

#ifdef ENVIRONMENT_VARS
unsigned char flUse8Bit;
unsigned char flUseNFTLCache;
unsigned char flUseisRAM;

/*-----------------------------------------------------------------------*/
/*                 f l s e t E n v V a r                                 */
/*  Sets the value of all environment variables                          */
/*  Parameters : None                                                    */
/*-----------------------------------------------------------------------*/
void flSetEnvVar(void)
{

    unsigned long prevValue,flMtdBusAccessType,flSectorsVerifiedPerFolding,
		flVerifyWriteBdtl,flVerifyWriteBinary,flVerifyWriteOther;

	GetFlParams(&dwWinL,&dwWinH,&flUseisRAM,&flUseNFTLCache,&flUse8Bit,&flMtdBusAccessType,
		&flVerifyWriteBdtl,&flVerifyWriteBinary,&flVerifyWriteOther,
		&flSectorsVerifiedPerFolding);
/*	flSetEnvAll(FL_MTD_BUS_ACCESS_TYPE,flMtdBusAccessType,&prevValue);
	flSetEnvAll(FL_SECTORS_VERIFIED_PER_FOLDING,flSectorsVerifiedPerFolding,&prevValue);
	flSetEnvAll(FL_VERIFY_WRITE_BDTL,flVerifyWriteBdtl,&prevValue);
	flSetEnvAll(FL_VERIFY_WRITE_BINARY,flVerifyWriteBinary,&prevValue);
	flSetEnvAll(FL_VERIFY_WRITE_OTHER,flVerifyWriteOther,&prevValue);
*/    
    flUse8Bit = 1;
    flUseNFTLCache = 1;
    flUseisRAM = 0;
}
#endif /* ENVIRONMENT_VARS */

/*----------------------------------------------------------------------*/
/*                f l R e g i s t e r C o m p o n e n t s               */
/*                                                                      */
/* Register socket, MTD and Translation Layer components for usage      */
/*                                                                      */
/* This function is called by FLite once only, at initialization of the */
/* FLite system.                                                        */
/*                                                                      */
/* Parameters:                                                          */
/*      None                                                            */
/*                                                                      */
/*----------------------------------------------------------------------*/

FLStatus flRegisterComponents(void)
{
    FLStatus statPlus;
	/* Registering socket interface */

    if(	(statPlus=flRegisterDOCPLUSSOC(dwWinL,dwWinH)) == flOK ) {
	/* Registering MTD's */
	flRegisterDOCPLUS();	/* Register DiskOnChip Millennium Plus MTD */
	/* Registering translation layers */
	flRegisterINFTL();		/* Register inftl.c */
    }

    return (statPlus==flOK) ? flOK : flAdapterNotFound;
}
