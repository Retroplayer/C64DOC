/* (c) 2003, 2004 Synology Inc.,  */
#include <linux/version.h>

#include <linux/module.h>			/* must be included after <linux/modversions.h> */

#include <asm/io.h>				/* isa_write...() */
#include <linux/ioport.h>			/* request_mem_reqion() */
#include <linux/delay.h>			/* udelay() */

#ifdef DEEPDEBUG
	#define LOG_DELAY	 flsleep(1)
#else
	#define LOG_DELAY
#endif

#include <linux/init.h>				/* __initdata */
#include <linux/sched.h>
#include <linux/kernel.h>			/* printk() */
#include <linux/slab.h>				/* kmalloc() */
#include <linux/vmalloc.h>
#include <linux/fs.h>				/* everything... */
#include <linux/errno.h>			/* error codes */
#include <linux/timer.h>
#include <linux/fcntl.h>			/* O_ACCMODE */
#include <linux/hdreg.h>			/* HDIO_GETGEO */
#include <linux/devfs_fs_kernel.h>	/* devfs_handle_t */
#include <linux/smp_lock.h>			/* lock_kernel() */
#include <linux/proc_fs.h>			/* create_proc_read_entry() */
#include <asm/system.h>				/* cli(), *_flags */
#include <asm/uaccess.h>			/* verify_area() */
#include <linux/major.h>
#include <linux/blk.h>
#include <linux/blkpg.h>
#include <linux/mtd/mtd.h>
#ifdef SYNO_IXP425
#include <asm/hardware.h>
#endif

#include "fldrvlnx.h"

/* private includes for M-Systems OSAK */
#include "tffs2lnx.h"
#include "flreq.h"
#include "docbdk.h"
#include "_blkdev.h"
#include "docsys.h"
#include "blockdev.h"

#ifndef memzero
#define memzero(s, n)     memset ((s), 0, (n))
#endif

static char *MsysPartitionName[] =
{ "REDB", "ZIMG", "RDGZ", "ALLL", 
"VEND", "SYNO", "RCFG", "FISD" };
             
#define DEVICE_NAME "M-sys DOCPLUS"
#define DEVICE_NR(device) (MINOR(device))

short GetFlDebugParam(void);

#ifdef DEEPDEBUG
static short __initdata			fl_debug = 1;
#else
static short __initdata			fl_debug = 1;
#endif
static short 	fl_usecount = 0;
static unsigned long __initdata		fl_winl=FL_DOC_PHYS_ADDR_LOW;
static unsigned long __initdata		fl_winh=FL_DOC_PHYS_ADDR_HIGH;
static void * __initdata		fl_virl=NULL;
static void * __initdata		fl_virh=NULL;
static short __initdata			fl_nftl_cache=1;
static short __initdata			fl_is_ram_check=0;
static short __initdata			fl_8bit_access=1;
static unsigned long __initdata		fl_mtd_bus_access_type=(FL_BUS_HAS_16BIT_ACCESS|FL_NO_ADDR_SHIFT);
static unsigned long __initdata		fl_verify_write_bdtl=0;
static unsigned long __initdata		fl_verify_write_binary=0;
static unsigned long __initdata		fl_verify_write_other=0;
static unsigned long __initdata		fl_sectors_verified_per_folding=64;
int __initdata fMsysDocDetected = MSYS_DOSPLUS_NOT_CHECK_YET;  

// function declarations

int fl_open(struct inode *inode, struct file *filp);
int fl_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg);
ssize_t fl_read(struct file *, char *, size_t, loff_t *);
ssize_t fl_readEx(struct file *, char *, size_t, loff_t *);
ssize_t fl_write(struct file *, const char *, size_t, loff_t *);
ssize_t fl_writeEx(struct file *, const char *, size_t, loff_t *);
int fl_release(struct inode *inode, struct file *filp);

static struct file_operations fl_fops = {
	open: fl_open,                   // open
	release: fl_release,             // release 
	ioctl: fl_ioctl,                 // ioctl 
	read: fl_readEx,
	write: fl_writeEx
};

int fl_open(struct inode *inode, struct file *filp)
{
	int dev_nr;

	dev_nr = DEVICE_NR(inode->i_rdev);
	if (dev_nr >= SYNO_MSYS_PARTITION_NUMBER * 2)
	{
		return -ENODEV;
	}
    
    if (dev_nr % 2)
        return -ENODEV;

    if (fl_usecount)
        return -EBUSY;  /* mutul exclusive access */

    fl_usecount = 1;        /* not SMP safe */

	return 0;					/* success */
}

int fl_release(struct inode *inode, struct file *filp)
{
	int             dev_nr;

	// get the real device number
	dev_nr = DEVICE_NR(inode->i_rdev);
	
    if (dev_nr >= SYNO_MSYS_PARTITION_NUMBER * 2)
	{
		return -ENODEV;
	}

    if (dev_nr % 2)
        return -ENODEV;

    invalidate_buffers(inode->i_rdev);
    fl_usecount = 0;

	return (0);
}

/* Init DiskOnChip CS in H/W if needed */
void fl_docCsInit( void )
{

}

/* Initialize the DiskOnChip Memory and Chip Select if needed */
int fl_mapPhysMem( unsigned long winl, unsigned long winh )
{
    unsigned long docSize = FL_DOC_WIN_SIZE + (winh - winl);
    unsigned long docAddr = winl;

    fl_virl = 0;
    /* Init DiskOnChip CS in H/W if needed */
    fl_docCsInit(); 

    if( !request_mem_region( docAddr, docSize, "fla") ) {
        printk(KERN_ERR "M-sys DOCPLUS: fl_mapPhysMem request region failure %lx\n",docAddr);
        return 1;
    }

    /* Get Mapped address */
    fl_virl = (void *)ioremap_nocache( docAddr, docSize );
    fl_virh = fl_virl + (docSize - FL_DOC_WIN_SIZE);
    return 0;
}

/* Release the DiskOnChip Memory */
void fl_releasePhysMem( unsigned long winl, unsigned long winh )
{    
    unsigned long docSize = FL_DOC_WIN_SIZE + (winh - winl);
  
    if( fl_virl ) {
        iounmap( fl_virl );       
        release_mem_region( winl, docSize );
    } 
}

void fl_info(void)
{
	IOreq ioreq;
    int ret;
    PhysicalInfo data;

	ioreq.irHandle = 0x00;
	ioreq.irData = &data;

    if(flOK != (ret = flGetPhysicalInfo(&ioreq)))  {
        printk("M-sys DOCPLUS: flGetPhysicalInfo failed, errcode %d\n", ret);
        return;
    }
    printk("M-sys DOCPLUS: Flash device type %x, Media Type %d\n",(unsigned) data.type, (unsigned) data.mediaType);
    printk("M-sys DOCPLUS: unitSize %d, mediaSize %d, chipSize %d, interleaving %d\n",  
           (unsigned) data.unitSize, (unsigned) data.mediaSize, (unsigned) data.chipSize, (unsigned) data.interleaving);
}

void fl_FillMsysPartitionSign(char *oldSign,struct file *file) 
{
    int minor = MINOR(file->f_dentry->d_inode->i_rdev) / 2;

    if((minor < 8) && (minor >= 0)) {
        memcpy(oldSign,MsysPartitionName[minor],4);
    }
    else {
        memcpy(oldSign,"\0\0\0\0",4);
    }
}

static inline unsigned long fl_DevFiletoHandle(struct file *file) 
{
    return 0x00UL;
}

int fl_GetPartitionInfo(int *arg) 
{
    IOreq ioreq;
	BDKStruct bdkstr;
	FLStatus status;
    int rgPartitionInfo[SYNO_MSYS_PARTITION_NUMBER * 2];
    int i;
   
    for(i=0; i < SYNO_MSYS_PARTITION_NUMBER; i++) {

        memzero(&ioreq, sizeof(IOreq));
        memzero(&bdkstr, sizeof(BDKStruct));
        ioreq.irHandle = 0x00;
        ioreq.irData = &bdkstr;
        bdkstr.startingBlock = 0;
        bdkstr.signOffset = 8;
        bdkstr.flags = EDC; 
        bdkstr.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
        memcpy(bdkstr.oldSign, MsysPartitionName[i], 4);
        status = bdkPartitionInfo(&ioreq);

        if(flOK != status) {
            printk("M-sys DOCPLUS: bdkGetBootPartitionInfo failed, status = %d\n",status);
            return -EIO;
        }
        else {
            /* printk("M-sys DOCPLUS: Partition %d, Size %d bytes, Realsize %d bytes\n",
                   i, bdkstr.startingBlock, bdkstr.length); */
            rgPartitionInfo[i*2] = bdkstr.startingBlock;   /* Partition size */
            rgPartitionInfo[i*2 + 1] = bdkstr.length;  /* real size */
        }
    }

    if(copy_to_user( arg, rgPartitionInfo, 2 * SYNO_MSYS_PARTITION_NUMBER * sizeof(int)))
        return -EFAULT;
    
    return 0;
}

int fl_partition(int *arg) 
{
    int rgPartitionSize[SYNO_MSYS_PARTITION_NUMBER];
    IOreq ioreq;
	BDKStruct bdkstr;
	FLStatus status;
    int i;
   
    if(copy_from_user(rgPartitionSize, arg, SYNO_MSYS_PARTITION_NUMBER * sizeof(int)))
        return -EFAULT;

    memzero(&ioreq, sizeof(IOreq));
    memzero(&bdkstr, sizeof(BDKStruct));

    ioreq.irHandle = 0x00;
    ioreq.irData = &bdkstr;

    for(i=0; i < SYNO_MSYS_PARTITION_NUMBER; i++) {
        bdkstr.length = rgPartitionSize[i];
        bdkstr.signOffset = 8;
        memcpy(bdkstr.newSign, MsysPartitionName[i], 4);

        printk("M-sys DOCPLUS: +Partition %d, Size %d (16k block), Signature %c%c%c%c\n",i,rgPartitionSize[i],
              bdkstr.newSign[0],bdkstr.newSign[1],bdkstr.newSign[2],bdkstr.newSign[3]  );
        status = bdkCreate(&ioreq);
        if(flOK != status) {
            printk("M-sys DOCPLUS: bdkCreate failed, status = %d\n",status);
            return -EFAULT;
        }
    }

    return 0;
}

int fl_format(int arg)
{
    IOreq ioreq;
    FormatParams2 param;
	FLStatus status;
    BDTLPartitionFormatParams BDTLparam;
    BinaryPartitionFormatParams binparam;

    memzero(&ioreq, sizeof(IOreq));
    memzero(&param, sizeof(FormatParams2));
    memzero(&BDTLparam, sizeof(BDTLPartitionFormatParams));
    memzero(&binparam, sizeof(BinaryPartitionFormatParams));

    param.percentUse = 95;  /* 98 recommeded in SDK document */
    param.noOfBDTLPartitions = 1;   /* cannot be 0 according to SDK doc */
    param.noOfBinaryPartitions = 1;
    param.progressCallback = NULL;
    param.BDTLPartitionInfo = &BDTLparam;
    param.binaryPartitionInfo = &binparam;

    BDTLparam.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
    BDTLparam.noOfFATcopies = 2;
    BDTLparam.noOfSpareUnits = 2;
    BDTLparam.flags = TL_NORMAL_FORMAT;

    if(arg > 0) 
        binparam.length = arg * SYNO_MSYS_FLASH_BLOCK_SIZE;
    else
        binparam.length = SYNO_MSYS_TOTAL_UNITS * SYNO_MSYS_FLASH_BLOCK_SIZE;
    binparam.signOffset = 8;

    ioreq.irHandle = 0x00;
    ioreq.irData = &param;
    ioreq.irFlags = TL_NORMAL_FORMAT;

    status = flFormatPhysicalDrive(&ioreq);

    if(flOK != status) {
        printk("M-sys DOCPLUS: flFormatPhysicalDrive failed, status = %d\n",status);
        return -EFAULT;
    }
    else
        printk("M-sys DOCPLUS: flFormatPhysicalDrive successed\n");

    return 0;
}

ssize_t fl_write(struct file *file, const char *buf, size_t count, loff_t *position)
{
    IOreq ioreq;
	FLStatus status;
	BDKStruct bdkstr;
	byte *pBuf;
    
    if(count < 0)
        return -EIO;

    if(count > SYNO_MSYS_FLASH_BLOCK_SIZE) {
        printk("M-sys DOCPLUS: fl_write count is larger than %d bytes\n",SYNO_MSYS_FLASH_BLOCK_SIZE);
        return -EIO;
    }

    if(*position % SYNO_MSYS_FLASH_BLOCK_SIZE) {
        printk("M-sys DOCPLUS: fl_write position(%lld) is not %d aligned\n",*position,SYNO_MSYS_FLASH_BLOCK_SIZE);
        return -EIO;
    }

    pBuf = kmalloc(SYNO_MSYS_FLASH_BLOCK_SIZE, GFP_KERNEL);
    memzero(pBuf, SYNO_MSYS_FLASH_BLOCK_SIZE); 

    if(pBuf == NULL)
        return -ENOMEM;

    memzero(&bdkstr, sizeof(BDKStruct));
	bdkstr.startingBlock = (*position / SYNO_MSYS_FLASH_BLOCK_SIZE);
    bdkstr.flags = EDC; 
	bdkstr.signOffset = 8;
	bdkstr.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
	ioreq.irHandle = fl_DevFiletoHandle(file);
    fl_FillMsysPartitionSign(bdkstr.oldSign,file);
	ioreq.irData = &bdkstr;
	
    status = bdkWriteInit(&ioreq);
	if(status!=flOK) {		
		kfree(pBuf);
		if(status == flNoSpaceInVolume)
			return 0;
		else {
			printk("M-sys DOCPLUS: Can't init BDK Write partition = %d\n",status);
			return -EIO;
		}
	}

        
    bdkstr.flags = ERASE_BEFORE_WRITE;
    bdkstr.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
    bdkstr.bdkBuffer = pBuf;
    ioreq.irData = &bdkstr;

	memcpy(pBuf, buf, count);

    status = bdkWriteBlock(&ioreq);

    if (status != flOK) {
        printk("M-sys DOCPLUS: write data error at %x, error code = %d\n", (unsigned) pBuf, status);
        kfree(pBuf);
        return -EIO;
    }

    kfree(pBuf);

    *position += count;
    return count;
}

ssize_t fl_writeEx(struct file *file, const char *buf, size_t count, loff_t *position)
{	
	size_t cbWrite = count;
	int ret = 0;
	char *pch = (char *)buf;
	char *szBuf = NULL;
	loff_t cur_pos = *position;
	size_t offset = 0;
	size_t cbLastWrite = 0, cbTotalWrite = 0;

	if (buf == NULL || count < 0) 
	{
		return -EFAULT;
	}
	else if (count == 0)
	{
		return 0;
	}

	szBuf = kmalloc(SYNO_MSYS_FLASH_BLOCK_SIZE, GFP_KERNEL);

	if(szBuf == NULL)
		return -ENOMEM;

	if (*position % SYNO_MSYS_FLASH_BLOCK_SIZE)
	{
		/*	If the *position is not aligned to SYNO_MSYS_FLASH_BLOCK_SIZE*n,
		 *	we should carefully handle the first "offset" bytes
		 */
		cur_pos = (*position / SYNO_MSYS_FLASH_BLOCK_SIZE) * SYNO_MSYS_FLASH_BLOCK_SIZE;
		offset = (loff_t)(*position - cur_pos);
		cbWrite += offset;
	}

	do {
		if (cbWrite >= SYNO_MSYS_FLASH_BLOCK_SIZE)
		{			
			if (offset > 0)
			{
				/* To avoid changing the first "offset" bytes, the original
				 * data should be read to szBuf first
				 */
				ret	= fl_read(file, szBuf, SYNO_MSYS_FLASH_BLOCK_SIZE, &cur_pos);
				if (ret == 0)
				{
					memzero(szBuf, SYNO_MSYS_FLASH_BLOCK_SIZE);
					cur_pos += SYNO_MSYS_FLASH_BLOCK_SIZE;					
				}
				else if (ret != SYNO_MSYS_FLASH_BLOCK_SIZE)
				{
					goto error;
				}
				cur_pos -= SYNO_MSYS_FLASH_BLOCK_SIZE;
			}

			if (copy_from_user(szBuf+offset, pch, SYNO_MSYS_FLASH_BLOCK_SIZE-offset))
			{
				ret	= -EFAULT;
				goto error;
			}
			cbLastWrite = SYNO_MSYS_FLASH_BLOCK_SIZE-offset;
			cbWrite -= SYNO_MSYS_FLASH_BLOCK_SIZE;
			pch += (SYNO_MSYS_FLASH_BLOCK_SIZE-offset);
			if (offset)
			{
				/* the value is only used on handle first segment of 
				 * data, assign value 0 to make following codes run 
				 * properly.
				 */
				offset = 0;
			}
		}
		else 
		{
			/* 	cbWrite < SYNO_MSYS_FLASH_BLOCK_SIZE: 
			 *	This part of codes only run on writing the last 
			 *	segment of data. 
			 *	1. Read the original data (SYNO_MSYS_FLASH_BLOCK_SIZE bytes)
			 *	2. Replace first cbWrite bytes with new content
			 *	3. Write the modified data back
			 */ 
			ret	= fl_read(file, szBuf, SYNO_MSYS_FLASH_BLOCK_SIZE, &cur_pos);
			if (ret == 0)
			{
				memzero(szBuf, SYNO_MSYS_FLASH_BLOCK_SIZE);
				cur_pos += SYNO_MSYS_FLASH_BLOCK_SIZE;					
			}
			else if (ret != SYNO_MSYS_FLASH_BLOCK_SIZE)
			{				
				goto error;
			}
			cur_pos -= SYNO_MSYS_FLASH_BLOCK_SIZE;

			if (copy_from_user(szBuf+offset, pch, cbWrite-offset))
			{
				ret	= -EFAULT;
				goto error;
			}
			cbLastWrite = cbWrite-offset; 
			cbWrite = 0;
		}			

		ret = fl_write(file, szBuf, SYNO_MSYS_FLASH_BLOCK_SIZE, &cur_pos);

		if (ret != SYNO_MSYS_FLASH_BLOCK_SIZE) {
			if(ret < 0) 
				goto error;
			else 
			{
				/* ret == 0, no free space in this volume */
				*position += cbTotalWrite;
				kfree(szBuf);
				
				if(cbTotalWrite == 0) 
					return -ENOSPC;
				else
					return cbTotalWrite;
			}
		}

		cbTotalWrite += cbLastWrite;				
	} while ( cbWrite != 0);

	*position += count;
	return count;
error:
	kfree(szBuf);
	return ret;
} /* fl_writeEx() */


ssize_t fl_read(struct file *file, char *buf, size_t count, loff_t *position)
{
	IOreq ioreq;
	FLStatus status;
	BDKStruct bdkstr;
	byte *pBuf;
	int	length = count;


	if(count != SYNO_MSYS_FLASH_BLOCK_SIZE ) {
		printk("M-sys DOCPLUS: fl_read count is not %d bytes\n",SYNO_MSYS_FLASH_BLOCK_SIZE);
		return -EIO;
	}

    if(*position % SYNO_MSYS_FLASH_BLOCK_SIZE) {
        printk("M-sys DOCPLUS: fl_read position(%lld) is not %d aligned\n",*position,SYNO_MSYS_FLASH_BLOCK_SIZE);
        return -EIO;
    }

    pBuf = kmalloc(SYNO_MSYS_FLASH_BLOCK_SIZE, GFP_KERNEL);

    if(pBuf == NULL)
        return -ENOMEM;

    memzero(&bdkstr, sizeof(BDKStruct));
	bdkstr.startingBlock = (*position / SYNO_MSYS_FLASH_BLOCK_SIZE);
    bdkstr.flags = EDC;	
	bdkstr.signOffset = 8;
	bdkstr.length = length;
    ioreq.irHandle = fl_DevFiletoHandle(file);
    fl_FillMsysPartitionSign(bdkstr.oldSign,file);
	ioreq.irData = &bdkstr;
	
    status = bdkReadInit(&ioreq);
	if(status!=flOK ) {
		kfree(pBuf);
		if(status == flNoSpaceInVolume)
			return 0;
		else {
			printk("M-sys DOCPLUS: Can't init BDK Read partition = %d\n",status);
			return -EIO;
		}
	}

    bdkstr.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
    bdkstr.bdkBuffer = pBuf;
    ioreq.irData = &bdkstr;
       
    status = bdkReadBlock(&ioreq);
        
    if (status != flOK)  {
        kfree(pBuf);
       /* printk("read data error at %x, error code = %d\n",(unsigned) pBuf, status); */
		return 0;
    }
    else {
		memcpy(buf, pBuf, SYNO_MSYS_FLASH_BLOCK_SIZE);
    }

    kfree(pBuf);

    *position += length;
    return length;
}

ssize_t fl_readEx(struct file *file, char *buf, size_t count, loff_t *position)
{
	char *szBuf;
	size_t cbRead = count;
	int ret;
	char *pch = (char *)buf;
	loff_t cur_position = *position;
	size_t offset = 0;	
	size_t cbLastRead = 0, cbTotalRead = 0;
	
	if (buf == NULL || count < 0) 
	{
		return -EFAULT;
	}
	else if (count == 0)
	{
		return 0;
	}

	szBuf = kmalloc(SYNO_MSYS_FLASH_BLOCK_SIZE, GFP_KERNEL);

	if(szBuf == NULL)
		return -ENOMEM;

	if (*position % SYNO_MSYS_FLASH_BLOCK_SIZE)
	{
		/*	If the *position is not aligned to SYNO_MSYS_FLASH_BLOCK_SIZE*n,
		 *	we should carefully handle the first "offset" bytes
		 */
		cur_position = (*position / SYNO_MSYS_FLASH_BLOCK_SIZE) * SYNO_MSYS_FLASH_BLOCK_SIZE;
		offset = (loff_t)(*position - cur_position);
		cbRead += offset;
	}

	do {
		ret = fl_read(file, (void *)szBuf, SYNO_MSYS_FLASH_BLOCK_SIZE, &cur_position);
		if (ret == 0)
		{
			/* 	fl_read() returning 0 means:
			 * 	1.There is no free space
			 * 	2.or no more data could be read
			 *	return number of bytes read now.
			 */
			*position += cbTotalRead;
			kfree(szBuf);
			return cbTotalRead;
		}
		else if (ret != SYNO_MSYS_FLASH_BLOCK_SIZE) 
		{
			goto out;
		}

		if (cbRead >= SYNO_MSYS_FLASH_BLOCK_SIZE)
		{
			if(copy_to_user(pch, szBuf+offset, SYNO_MSYS_FLASH_BLOCK_SIZE-offset)) {
				ret = -EFAULT;
				goto out;
			}
			
			cbLastRead = SYNO_MSYS_FLASH_BLOCK_SIZE-offset;
			pch += (SYNO_MSYS_FLASH_BLOCK_SIZE-offset);
			if(offset) 
			{
				/* the value is only used on handle first segment of 
				 * data, assign value 0 to make following codes run 
				 * properly.
				 */
				offset = 0;
			}
			cbRead -= SYNO_MSYS_FLASH_BLOCK_SIZE;
		}
		else /* cbRead < SYNO_MSYS_FLASH_BLOCK_SIZE */
		{			
			if(copy_to_user(pch, szBuf+offset, cbRead-offset)){
				ret	= -EFAULT;
				goto out;
			}
			cbLastRead = cbRead-offset; 
			cbRead = 0;
		}
		
		cbTotalRead += cbLastRead;
	} while ( cbRead != 0);

	kfree(szBuf);
	*position += count;
	return count;

out:
	kfree(szBuf);
	return ret;
} /* fl_readEx() */


int fl_writeipl(const char *buf)
{
	IOreq ioreq;
	byte *pBuf;

	pBuf = (unsigned char *)kmalloc(1024,GFP_KERNEL);

    if(pBuf==NULL) 
        return -ENOMEM;

    if(copy_from_user(pBuf, buf, 1024))  {
        kfree(pBuf);
        return -EFAULT;
    }
    
	ioreq.irHandle = 0x00;
	ioreq.irData = pBuf;
    ioreq.irLength = 1024;
    ioreq.irFlags = FL_IPL_MODE_NORMAL;

    if(flOK != flWriteIPL(&ioreq)) {
        printk("M-sys DOCPLUS: flWriteIPL failed\n");
        return -EIO;
    }

    kfree(pBuf);
    return 0;
}

void fl_dumpipl(void)
{
	IOreq ioreq;
	byte *pBuf;
    int i = 0;
    int ret;

	pBuf = (unsigned char *)kmalloc(1024,GFP_KERNEL);

    if(pBuf==NULL) 
        return;

	ioreq.irHandle = 0x00;
	ioreq.irData = pBuf;
    ioreq.irLength = 1024;

    if(flOK != (ret = flReadIPL(&ioreq))) {
        printk("flReadIPL failed\n");
        return;
    }

	while(i <= 1024){
		printk("%8.8x    %2.2x%2.2x %2.2x%2.2x %2.2x%2.2x %2.2x%2.2x %2.2x%2.2x %2.2x%2.2x %2.2x%2.2x %2.2x%2.2x\n",
					i, *pBuf, *(pBuf+1),
							*(pBuf+2), *(pBuf+3), *(pBuf+4), *(pBuf+5), *(pBuf+6), *(pBuf+7),
							*(pBuf+8), *(pBuf+9), *(pBuf+10), *(pBuf+11), *(pBuf+12), *(pBuf+13),
							*(pBuf+14), *(pBuf+15));
		pBuf += 16;
		i += 16;
	}

    kfree(pBuf);
}

void fl_exit(void)
{
    /* only call flExit if msys flash is detected */
    if(MSYS_DOCPLUS_FOUND==fMsysDocDetected)
        flExit();
}

#ifdef SYNO_IXP425

extern int gVenderMacNumber;
extern char grgbLanMac[3][6];

void fl_ReadMacAddress(void)
{
    u_char rgbszBuf[64];
    size_t retlen;
    int i, n, x; 
    unsigned int Sum;
    u_char ucSum;

	IOreq ioreq;
	FLStatus status;
	BDKStruct bdkstr;
	byte *pBuf = NULL;

    pBuf = kmalloc(SYNO_MSYS_FLASH_BLOCK_SIZE, GFP_KERNEL);

    if(pBuf == NULL) {
        printk("M-sys DOCPLUS: fl_ReadMacAddress() cannot allocate memory\n");
        goto out;
    }

    memzero(&bdkstr, sizeof(BDKStruct));
	bdkstr.startingBlock = 0;
    bdkstr.flags = EDC;	
	bdkstr.signOffset = 8;
	bdkstr.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
    ioreq.irHandle = 0x00;
    memcpy(bdkstr.oldSign,MsysPartitionName[4],4);    /* read from "VEND" partition */
	ioreq.irData = &bdkstr;
	
    status = bdkReadInit(&ioreq);
	if(status!=flOK) {
        printk("M-sys DOCPLUS: fl_ReadMacAddress() bdkReadInit failed, status = %d\n", status);
        goto out;
    }

    bdkstr.length = SYNO_MSYS_FLASH_BLOCK_SIZE;
    bdkstr.bdkBuffer = pBuf;
    ioreq.irData = &bdkstr;
    status = bdkReadBlock(&ioreq);
	if(status!=flOK) {
        printk("M-sys DOCPLUS: fl_ReadMacAddress() bdkReadBlock failed, status = %d\n", status);
        goto out;
    }        
    
    memcpy(rgbszBuf, pBuf, 64);
    retlen = 64;

    /* copy & modified from code in add_mtd_partitions() */
    {        
        x = 0;
        gVenderMacNumber = 0; /* rgbszBuf[x]; */
        /* if (gVenderMacNumber > 2) gVenderMacNumber=0; */
        for (n = 0; n<2 /* gVenderMacNumber */; n++) {
            for (Sum=0,ucSum=0,i=0; i<6; i++) {
                Sum+=rgbszBuf[i+x];
                ucSum+=rgbszBuf[i+x];
                grgbLanMac[n][i] = rgbszBuf[i+x];
            }
            x+=6;
            if (Sum==0 || ucSum!=rgbszBuf[x]) {
                printk("vender Mac%d checksum error ucSum:0x%02x Buf:0x%02x Sum:%d.\n", n, ucSum, rgbszBuf[x], Sum);
                /* gVenderMacNumber = 0; */
                break;
            } else {
                printk("Mac%d %02x:%02x:%02x:%02x:%02x:%02x\n", gVenderMacNumber, grgbLanMac[n][0], grgbLanMac[n][1], grgbLanMac[n][2], grgbLanMac[n][3], grgbLanMac[n][4], grgbLanMac[n][5]);
                gVenderMacNumber++;
            }
            x++;
        }
        printk("Vender partition MacNum:%d retlen:%d\n", gVenderMacNumber, retlen);
    }

out:

    if(pBuf)
        kfree(pBuf);
}
#endif

#ifdef MY_ABC_HERE
extern unsigned long SystemHardwareInfo;
#endif
int fl_init(void)
{
	int result = 0;

	// Map Physical Memory of the DiskOnChip window
	if( fl_mapPhysMem( fl_winl, fl_winh ) ) {
		printk(KERN_ERR"Cannot Map M-Systems DiskOnChip Memory\n");
		goto fl_init_error;
	}
	
	// can we initialize OSAK?
	if(!FlInit())
	{
		printk("M-sys DOSPLUS: not detected\n");
		goto fl_init_error;
	}
#define MAX_MSYS_DEVICES 1
	/* find out how many devices we have */
	if(!FlGetNumberOfDevices(MAX_MSYS_DEVICES))
	{
		printk("M-sys DOSPLUS: Cannot find any M-Systems flash devices\n");
		goto fl_init_error;		
	}
    fl_info();

	if ((result = devfs_register_chrdev(MTD_CHAR_MAJOR,DEVICE_NAME,&fl_fops)) < 0)
	{
		printk("M-sys DOSPLUS: can't register major %d\n",MTD_CHAR_MAJOR);
		goto fl_init_error;
	}

#ifdef SYNO_IXP425

#define EXP_RECOVERY_SHIFT  16
#define EXP_HOLD_SHIFT  20
#define EXP_STROBE_SHIFT    22
#define EXP_SETUP_SHIFT 26
#define EXP_ADDR_SHIFT  28

#define EXP_RECOVERY_T(x)   (((x) & 15) << EXP_RECOVERY_SHIFT)
#define EXP_HOLD_T(x)       (((x) & 3)  << EXP_HOLD_SHIFT)
#define EXP_STROBE_T(x)     (((x) & 15) << EXP_STROBE_SHIFT)
#define EXP_SETUP_T(x)      (((x) & 3)  << EXP_SETUP_SHIFT)
#define EXP_ADDR_T(x)       (((x) & 3)  << EXP_ADDR_SHIFT)

#define EXP_SZ_16M          (15 << 10)
#define EXP_WR_EN           (1 << 1)
#define EXP_BYTE_RD16       (1 << 6)
#define EXP_CS_EN           (1 << 31)

#define IXP425_EXP_CS0_INIT \
 (EXP_ADDR_T(1) | EXP_SETUP_T(1) | EXP_STROBE_T(1) | EXP_HOLD_T(1) | \
  EXP_RECOVERY_T(1) | EXP_SZ_16M | EXP_WR_EN | EXP_BYTE_RD16 | EXP_CS_EN)

    *IXP425_EXP_CS0 = IXP425_EXP_CS0_INIT;    
#endif
    fMsysDocDetected = MSYS_DOCPLUS_FOUND;
#ifdef MY_ABC_HERE
    SystemHardwareInfo |= SYNO_IXP420_MSYS_FLASH_USED;
#endif
#ifdef SYNO_IXP425
    fl_ReadMacAddress();
#endif
	return 0;

fl_init_error:
    	
    fl_releasePhysMem( fl_winl, fl_winh );
    fMsysDocDetected = MSYS_DOCPLUS_NOT_FOUND;
	return(1);
}

int fl_ioctl(struct inode *inode, struct file *filp, unsigned int cmd, unsigned long arg)
{
	unsigned int dev_nr;
    int ret = -EINVAL;

    if (!capable(CAP_SYS_ADMIN))
        return -EACCES;

	dev_nr = DEVICE_NR(inode->i_rdev);

    switch (cmd){
        case MSYSMEMFORMAT:
            ret = fl_format(arg); 
            break;

        case MSYSMEMPARTITION:
            ret = fl_partition((int *)arg);
            break;

        case MSYSMEMPARTITIONINFO:
            ret = fl_GetPartitionInfo((int *)arg);
            break;

	    default: 
            ret = -EINVAL;           
            break;
    }

    return ret;
}


/*****************	EXPORTED TO TRUEFFS	*****************/

short GetFlDebugParam(void)
{
	return fl_debug;
}

void GetFlParams(unsigned long*p_fl_winl,unsigned long*p_fl_winh,
	unsigned char*p_fl_is_ram_check,unsigned char*p_fl_nftl_cache,
	unsigned char*p_fl_8bit_access,unsigned long*p_fl_mtd_bus_access_type,
	unsigned long*p_fl_verify_write_bdtl,unsigned long*p_fl_verify_write_binary,
	unsigned long*p_fl_verify_write_other,unsigned long*p_fl_sectors_verified_per_folding)
{
	*p_fl_winl=(unsigned long)fl_virl;
	*p_fl_winh=(unsigned long)fl_virh;
	*p_fl_is_ram_check=fl_is_ram_check;
	*p_fl_nftl_cache=fl_nftl_cache;
	*p_fl_8bit_access=fl_8bit_access;
	*p_fl_mtd_bus_access_type=fl_mtd_bus_access_type;
	*p_fl_verify_write_bdtl=fl_verify_write_bdtl;
	*p_fl_verify_write_binary=fl_verify_write_binary;
	*p_fl_verify_write_other=fl_verify_write_other;
	*p_fl_sectors_verified_per_folding=fl_sectors_verified_per_folding;
}

/* The following are the Linux versions of various things required by the M-Systems OSAK that must be compiled here in the Linux kernel environment. */
void flDelayMsecs(unsigned milliseconds)
{
	register int    i;
	for (i = 0; i < milliseconds; i++)
		udelay(1000L);
}

void flsleep(unsigned long milliseconds)
{
	unsigned long deltaj;
	/* Timeout has to be expressed in jiffies, there are HZ jiffies/sec. 
	We add one to it anyway, because the "first" jiffy is really some
	random fraction of a jiffy. */
	deltaj = 1 + ((HZ * milliseconds) / 1000);
	/* QQQ: why TASK_UNINTERRUPTIBLE? */
	current->state = TASK_UNINTERRUPTIBLE;
	while ((deltaj = schedule_timeout(deltaj)) > 0) /* skip */ ;
}

void *flmemcpy(void *dest, const void *src, size_t length)
{
	return(memcpy(dest, src, length));
}

void *flmemset(void *dest, int value, unsigned int length)
{
	return(memset(dest, value, length));
}

int flmemcmp(const void * dest,const void  *src,size_t count)
{
	return(memcmp(dest, src, count));
}

/*
 * Do not use isa_xxx() functions in order to access memory because
 * they are x86 specific and doesn't get proper virtual address from MMU
 * Instead use the pointer from ioremap_nocache(physAddr) with usual access
 * functions.
 */
void flmemcpy_fromio(void *dest, const void * src, unsigned int length)
{
/*#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	isa_memcpy_fromio(dest, (unsigned long)src, length);
#else
	memcpy_fromio(dest, src, length);
#endif
*/
	memcpy_fromio(dest, src, length);
}

void flmemcpy_toio(void *dest, const void * src, unsigned int length)
{
/*#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	isa_memcpy_toio((unsigned long)dest, src, length);
#else
	memcpy_toio(dest, src, length);
#endif
*/
	memcpy_toio(dest, src, length);
}

void flmemset_io(void *dest, int value, unsigned int length)
{
/*#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,4,0)
	isa_memset_io((unsigned long)dest, value, length);
#else
	memset_io(dest, value, length);
#endif
*/
	memset_io(dest, value, length);
}

void *flmalloc(unsigned long size)
{
	return vmalloc(size);
}

void flfree(void*addr)
{
	vfree(addr);
}

void FlDebugPrint(char*str)
{
	if(GetFlDebugParam())
	{
		LOG_DELAY;
		printk(KERN_DEBUG DEVICE_NAME": %s",str);
	}
}

void FlErrorPrint(char*str,int stat)
{
	LOG_DELAY;
	printk(KERN_DEBUG DEVICE_NAME": Error %s: %d\n",str,stat);
}

#ifdef DEEPDEBUG
int FlPrintk(const char *fmt, ...)
{
	va_list args;
	char buf[1024];     // hopefully enough, kernel/printk.c thinks so
	int i;

	va_start(args, fmt);
	i = vsprintf(buf, fmt, args); 
	va_end(args);
	// make sure we have terminated the string
	buf[i--] = '\0';

	// libosak uses \n\r, this make kerneld unhappy
	if (buf[i-1] == '\n' && buf[i] == '\r')
		buf[i--] = '\0';
	LOG_DELAY;
	printk(KERN_DEBUG"fl :%s",buf);
	return(i);
}

void FlLogData(unsigned short*wBuffPtr,unsigned short wLen,unsigned char fWrite)
{
	unsigned short w=0;

	LOG_DELAY;
	if(fWrite)
	{
		printk(KERN_DEBUG DEVICE_NAME": Write %u words\n",wLen);
	}
	else
	{
		printk(KERN_DEBUG DEVICE_NAME": Read %u words\n",wLen);
	}

	LOG_DELAY;
	while(w<wLen)
	{
		unsigned short w1;

		for(w1=0;w1<16&&w<wLen;w1++,w++)
		{
			printk("%4.4x ",wBuffPtr[w]);
		}
		printk("\n");
	}
}
#endif	/* DEEPDEBUG */

unsigned char flreadb(volatile void *addr)
{
	return(readb(addr));
}

unsigned short flreadw(volatile void *addr)
{
	return(readw(addr));
}

unsigned long flreadl(volatile void *addr)
{
	return(readl(addr));
}

void flwriteb(unsigned char value, volatile void *addr)
{
	writeb(value, addr);
}

void flwritew(unsigned short value, volatile void*addr)
{
	writew(value, addr);
}

void flwritel(unsigned long value, volatile void *addr)
{
	writel(value, addr);
}

unsigned int flRandByte(void)
{
	struct timeval time;
	do_gettimeofday(&time);
	return (time.tv_usec >> 1) & 0xff;
}

void *flAddLongToFarPointer(void*ptr, unsigned long offset)
{
	return (void*)(((unsigned long)(ptr)) + offset);
}

static struct semaphore osak_sem;

void flSysfunInit(void)
{
	sema_init(&osak_sem,1);
}

FLStatus flCreateMutex(FLMutex *mutex)
{
	up(&osak_sem);
	return 0;
}

void flDeleteMutex(FLMutex *mutex)
{
	up(&osak_sem);
}

int flTakeMutex(int*mutex)
{
	down(&osak_sem);
	return 1;
}

void flFreeMutex(int*mutex)
{
	up(&osak_sem);
}

module_exit(fl_exit);

