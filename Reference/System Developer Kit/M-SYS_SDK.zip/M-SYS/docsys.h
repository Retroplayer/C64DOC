/******************************************************************************
**  COPYRIGHT  2007 Marvell Inernational Ltd.
**  All Rights Reserved
******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*  Copyright (C), 1995-2006, msystems Ltd. All rights reserved.              */
/*                                                                            */
/*  Redistribution and use in source and binary forms, with or without        */
/*  modification, are permitted provided that the following conditions are    */
/*  met:                                                                      */
/*  1. Redistributions of source code must retain the above copyright notice, */
/*     this list of conditions and the following disclaimer.                  */
/*  2. Redistributions in binary form must reproduce the above copyright      */
/*     notice, this list of conditions and the following disclaimer in the    */
/*     documentation and/or other materials provided with the distribution.   */
/*  3. Neither the name of msystems nor the names of its contributors may be  */
/*     used to endorse or promote products derived from this software without */
/*     specific prior written permission.                                     */
/*                                                                            */
/*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       */
/*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED */
/*  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR             */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     */
/*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  */
/*  TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    */
/*  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    */
/*  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      */
/*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        */
/*  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/*                                                                            */
/******************************************************************************/

/*
 * $Log:   V:/PVCSDB/DiskOnChip/archives/Testing/TrueFFS 6.3/Drop 2.5/3/bddoc/src/docsys.h-arc  $
 *
 *    Rev 1.3   Aug 09 2006 16:52:46   Polina.Marimont
 * initial for DOC Driver 1.0
 */

/************************************************************************/
/*                          I M P O R T A N T                           */
/*                                                                      */
/* The file contains DiskOnChip memory access routines and macros       */
/* defintions.                                                          */
/*                                                                      */
/* In order to use the complete set of TrueFFS memory access routine    */
/* that allows runtime configuration of each socket access type make    */
/* sure the FL_NO_USE_FUNC is not defined in FLCUSTOM.H.                */
/*                                                                      */
/* If you know the exact configuration of your application you can      */
/* uncomment the FL_NO_USE_FUNC definition and set the proper access    */
/* type using the macroe defintion bellow.                              */
/************************************************************************/

#ifndef DOCSYS_H
#define DOCSYS_H


#ifndef FL_NO_USE_FUNC

/* (public) types of DiskOnChip access configurations */

#define FL_BUS_HAS_XX_ACCESS_MASK  0x0000000FL /* Bus can access mask   */

#define FL_XX_ADDR_SHIFT_MASK      0x000000F0L /* Address shift mask   */

#endif /* FL_NO_USE_FUNC */

#include "_docsys.h"

#endif /* DOCSYS_H */
