/******************************************************************************
**  COPYRIGHT  2007 Marvell Inernational Ltd.
**  All Rights Reserved
******************************************************************************/

/******************************************************************************/
/*                                                                            */
/*  Copyright (C), 1995-2006, msystems Ltd. All rights reserved.              */
/*                                                                            */
/*  Redistribution and use in source and binary forms, with or without        */
/*  modification, are permitted provided that the following conditions are    */
/*  met:                                                                      */
/*  1. Redistributions of source code must retain the above copyright notice, */
/*     this list of conditions and the following disclaimer.                  */
/*  2. Redistributions in binary form must reproduce the above copyright      */
/*     notice, this list of conditions and the following disclaimer in the    */
/*     documentation and/or other materials provided with the distribution.   */
/*  3. Neither the name of msystems nor the names of its contributors may be  */
/*     used to endorse or promote products derived from this software without */
/*     specific prior written permission.                                     */
/*                                                                            */
/*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       */
/*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED */
/*  TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR             */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     */
/*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED  */
/*  TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR    */
/*  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF    */
/*  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING      */
/*  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS        */
/*  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.              */
/*                                                                            */
/******************************************************************************/
/*
 * $Log:   &
 */

/*****************************************************************************
* File Header                                                                *
* -----------                                                                *
* Name : flsystyp.h                                                          *
*                                                                            *
* Description : System defintions and types required for the implementation  *
*              of the system customization routines.                         *
*                                                                            *
*****************************************************************************/

#ifndef FLSYSTYPE_H
#define FLSYSTYPE_H


#include "_common.h"
#include "flsystem.h"

/* Boolean constants */
#ifndef FALSE
#define FALSE    0
#endif /* FALSE */
#ifndef TRUE
#define TRUE     1
#endif /* TRUE */


/* Zones for debug printing */

#define FLZONE_NONE       0
#define FLZONE_MTD        0x0001
#define FLZONE_BDK        0x0002
#define FLZONE_TL         0x0004
#define FLZONE_BLKDEV     0x0008
#define FLZONE_FORMAT     0x0010
#define FLZONE_FS         0x0020
#define FLZONE_SOCKET     0x0040
#define FLZONE_IOCTL      0x0080
#define FLZONE_PROD       0x0100
#define FLZONE_STATISTICS 0x0200
#define FLZONE_UTIL       0x0400
#define FLZONE_PARA       0x0800
#define FLZONE_ABS        0x1000
#define FLZONE_ATA        0x2000
#define FLZONE_API        0x4000
#define FLZONE_FULL       0xffff

#endif /* FLSYSTYPE_H */
